package com.emc.sdkclientdemo;

import com.whxx.emc.sdk.annotaion.EnableSubscribeClient;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableSubscribeClient
public class SdkClientDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SdkClientDemoApplication.class, args);
    }

}
