package com.emc.sdkclientdemo.handler;

import com.alibaba.fastjson.JSON;
import com.whxx.emc.sdk.client.SubscribeClient;
import com.whxx.emc.sdk.dto.CommandReqDTO;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * @author NieYinjun
 * @date 2019/7/11 8:55
 */
@Component
public class SendToDevice {
    @Resource
    private SubscribeClient subscribeClient;

    public void test(String yourAppId,String yourDeviceId,String payload){
        CommandReqDTO commandReqDTO = new CommandReqDTO();
        commandReqDTO.setAppId(yourAppId);
        commandReqDTO.setDeviceId(yourDeviceId);
        commandReqDTO.setCommand(payload);
        long msgId = subscribeClient.singleSend(commandReqDTO);
        System.out.println("下发消息："+JSON.toJSONString(commandReqDTO));
    }

    public void test(CommandReqDTO command){
        long msgId = subscribeClient.singleSend(command);
        System.out.println("下发消息："+JSON.toJSONString(command));
    }
}
