package com.emc.sdkclientdemo.handler;

import com.whxx.emc.sdk.api.vo.ApiResVO;
import com.whxx.emc.sdk.client.handler.AbstractMessageHandler;
import com.whxx.emc.sdk.dto.CommandResDTO;
import com.whxx.emc.sdk.dto.DeviceOnOffDTO;
import com.whxx.emc.sdk.dto.MessageDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class MyMessageHandler extends AbstractMessageHandler {

    @Override
    public void onMessage(MessageDTO messageDTO) {
        log.info("收到来自应用【{}】的消息，本次接收{}条",messageDTO.getProductId(),messageDTO.getTotal());
        log.info("消息内容：{}",messageDTO.getList());

    }

    @Override
    public void apiResponse(ApiResVO apiResVO) {
        log.info("查询名称：{}", apiResVO.getQueryName());
        log.info("查询返回结果：【{}】", apiResVO.getResult());
    }

    @Override
    public void commandRes(CommandResDTO res) {
        log.debug("指令下达结果：{}", res);
    }
    @Override
    public void deviceOnOff(DeviceOnOffDTO deviceOnOffDTO){
        log.info("设备【{}】上下线【{}】",deviceOnOffDTO.getDeviceId(),deviceOnOffDTO.getEvent());
    }
}
