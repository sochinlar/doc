package com.emc.httpclientdemo.service;

import com.alibaba.fastjson.JSON;
import com.emc.httpclientdemo.prop.RestProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.time.Duration;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * @author NieYinjun
 * @date 2019/7/11 14:53
 */
@Component
@Slf4j
public class SendToDevice {
    @Resource
    private RestTemplate restTemplate;
    @Resource
    private RestProperties restProperties;

    public String testSend(String deviceId,String payload){

        Map<String,Object> param = new HashMap<>();
        param.put("payload",payload);

        ResponseEntity<String> exchange = restTemplate.exchange(restProperties.getServerUrl()+"/recv/app/message/one",
                HttpMethod.POST, getHttpEntity(deviceId,JSON.toJSONString(param)), String.class);
        return exchange.getBody();
    }

    private <T> HttpEntity<T> getHttpEntity(String deviceId,T o){
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.add("appId", restProperties.getAppId());
        requestHeaders.add("deviceId", deviceId);
        requestHeaders.add("appSecret", restProperties.getAppSecret());
        requestHeaders.add("Content-Type", "application/json");
        return new HttpEntity<T>(o, requestHeaders);
    }

}
