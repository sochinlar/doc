package com.emc.httpclientdemo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author NieYinjun
 * @date 2019/7/11 11:49
 */
@Data
@NoArgsConstructor
public class MessageDTO {
    private MsgEvent event;
    private String productId;
    private Long total;
    private String deviceId;
    private Long eventTime;
    private List<MessageItemDTO> list;

}