package com.emc.httpclientdemo.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author NieYinjun
 * @date 2019/7/11 12:21
 */
@Data
@NoArgsConstructor
public class MessageItemDTO {
    /**设备ID*/
    private String deviceId;
    /**消息ID*/
    private String id;
    /**消息发送时间*/
    private Long receiveTime;
    /**设备发送消息内容*/
    private String payload;
}