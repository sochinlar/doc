package com.emc.httpclientdemo.dto;

/**
 * @author NieYinjun
 * @date 2019/7/11 11:50
 */
public enum MsgEvent {
    /**设备消息*/
    BIZ,
    /**设备上线*/
    ON,
    /**设备下线*/
    OFF
}
