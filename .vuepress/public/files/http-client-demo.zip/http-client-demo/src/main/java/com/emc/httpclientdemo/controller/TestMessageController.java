package com.emc.httpclientdemo.controller;

import com.emc.httpclientdemo.dto.MessageDTO;
import com.emc.httpclientdemo.service.SendToDevice;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @author NieYinjun
 * @date 2019/7/11 11:41
 */
@RestController
@RequestMapping("/test")
@Slf4j
public class TestMessageController {
    @Resource
    private SendToDevice sendToDevice;

    @RequestMapping("/send")
    public Object sendMessageToDevice(@RequestParam("deviceId") String deviceId,@RequestParam("payload") String payload){
        log.info("发送消息【{}】到设备【{}】",payload,deviceId);
        String result = sendToDevice.testSend(deviceId,payload);
        log.info("发送结果：" + result);
        return result;
    }


    /**
     * 通过EMC物联网平台后台管理页面配置的地址，会发送get请求
     * 如 填写  http://111.193.57.13:8080/test/notify          token填 xxxxx
     * 则平台会调用  http://111.193.57.13:8080/test/notify?token=xxxxx
     * 本接口则需要发回原值token即可
     * @param token
     * @return
     */
    @GetMapping("/notify")
    public String testTokenMessage(@RequestParam("token") String token) {
        //如果没有获取到token值，则请修改自己的接口
        System.out.println("验证请求，token="+token);
        return token;
    }
    /**
     * 模拟测试第三方应用回调地址
     *
     * @param messageDTO 载体
     * @return Map
     */
    @PostMapping("/notify")
    public void testCallback(@RequestBody MessageDTO messageDTO) {
        switch (messageDTO.getEvent()){
            case BIZ:
                handleBiz(messageDTO);
                break;
            case ON:
            case OFF:
                handleOnOff(messageDTO);
                break;
            default:
                handleOther(messageDTO);
                break;
        }
    }

    /**未知消息*/
    private void handleOther(MessageDTO messageDTO) {
        log.info("其他消息：{}",messageDTO);
    }

    /**设备上下线*/
    private void handleOnOff(MessageDTO messageDTO) {
        log.info("产品【{}】-设备【{}】于【{}】上下线【{}】",messageDTO.getProductId(),
                messageDTO.getDeviceId(),messageDTO.getEventTime(),messageDTO.getEvent());
    }

    /**设备发送的消息*/
    private void handleBiz(MessageDTO messageDTO) {
        log.info("产品【{}】收到{}条消息,时间【{}】：",messageDTO.getProductId(),
                messageDTO.getTotal(),messageDTO.getEventTime());
        log.info("消息内容：{}",messageDTO.getList());
    }


}
