package com.emc.httpclientdemo.prop;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author NieYinjun
 * @date 2019/7/11 16:14
 */
@Data
@NoArgsConstructor
@Component
@ConfigurationProperties(prefix = "rest")
public class RestProperties {
    private String serverUrl;
    private String appId;
    private String appSecret;
}
